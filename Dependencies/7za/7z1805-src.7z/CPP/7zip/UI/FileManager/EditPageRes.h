#define IDD_EDIT     2103
#define IDD_EDIT_2  12103

#define IDT_EDIT_VIEWER    543
#define IDT_EDIT_EDITOR   2104
#define IDT_EDIT_DIFF     2105

#define IDE_EDIT_VIEWER    100
#define IDB_EDIT_VIEWER    101

#define IDE_EDIT_EDITOR    102
#define IDB_EDIT_EDITOR    103

#define IDE_EDIT_DIFF      104
#define IDB_EDIT_DIFF      105
