#define USE_COPYRIGHT_CR
#include "../../C/7zVersion.h"
