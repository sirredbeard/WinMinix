// FilePathAutoRename.h

#ifndef __FILE_PATH_AUTO_RENAME_H
#define __FILE_PATH_AUTO_RENAME_H

#include "../../Common/MyString.h"

bool AutoRenamePath(FString &fullProcessedPath);

#endif
